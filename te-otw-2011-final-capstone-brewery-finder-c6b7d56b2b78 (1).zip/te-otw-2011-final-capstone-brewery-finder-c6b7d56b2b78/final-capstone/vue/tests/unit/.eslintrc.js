module.exports = {
  env: {
    mocha: true
  }
}