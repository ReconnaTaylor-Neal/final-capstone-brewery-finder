<template>
  <user-list />
</template>

<script>
import UserList from '../components/UserList.vue'
export default {
  components: { UserList },

}
</script>

<style>

</style>