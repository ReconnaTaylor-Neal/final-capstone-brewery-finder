<template>
<div>
  <br>
  <h1 class="home-title">Tech Ale-Evator Brewery Finder</h1>
  <div>
  <p class="home-blurb">The world's foremost resource for developer libations.  <!-- </p> -->
  <!-- <p class="home-blurb"> -->Because if this class didn't make you want to drink, nothing will!</p>
    </div>
   </div>
  
</template>

<script>
export default {
  name: "home"
};
</script>

<style>
.home-title{
  color:darkorange;
  margin: 0 auto;
  font-family: 'Noto Sans JP', sans-serif;
 /*  letter-spacing: 5px; */ 
  /* word-spacing: 10px; */
  font-size: 4vw;
  
  /* text-shadow: 2px 2px 5px; */
}
.home-blurb{
  color:darkorange;
  font-style: italic;
  /* text-shadow: 2px 2px 5px; */
}
</style>